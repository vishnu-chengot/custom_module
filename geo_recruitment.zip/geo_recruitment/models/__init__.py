from . import employee_documents
from . import hr_recruitment
from . import hr_stage
from . import token_key
from . import job_position_stage
from . import res_partner