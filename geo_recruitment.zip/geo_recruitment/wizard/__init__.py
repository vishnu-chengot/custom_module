from . import pdf_attachment
from . import candidate_profile
from . import candidate_resume_attachement
from . import applicant_wizard
# from . import applicant_multiple_wizard