# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class HrApplicant(models.Model):
    _inherit = 'hr.applicant'

    job_id_new = fields.Many2one('hr.job', string='Job Position')
    request_id = fields.Many2one('hr.recruitment.request',string='Enrolment Request ID', compute='_compute_enrollment_request_id',
                                        store=True)

    @api.depends('job_id_new')
    def _compute_enrollment_request_id(self):
        for record in self:
            record.request_id = record.job_id_new.recruitment_ref


    # @api.depends('job_id')
    # def get_recruitment_request(self):
    #     for rec in self:
    #         print('triggered-----------------')
    #         if rec.job_id:
    #             print('working-----------------')
    #             recruitment_object = self.env['hr.recruitment.request'].search(
    #                 [('job_id', '=', rec.job_id.id)])
    #             for recruitment in recruitment_object:
    #                 rec.request_id = recruitment.id
    #         else:
    #             rec.request_id = False

    def create_employee_from_applicant(self):
        res = super(HrApplicant, self).create_employee_from_applicant()
        res['context'].update({'default_request_id': self.request_id.id or False, })
        return res
